% use default Ts = 1
% with no loss of generality
z = tf('z');
A = 1/(z-1)
B = -2/z
C = (z+.1)/(z+.2)
D = .9

G = 1/z;
H = 1;